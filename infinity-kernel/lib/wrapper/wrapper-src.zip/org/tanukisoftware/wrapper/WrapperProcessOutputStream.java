package org.tanukisoftware.wrapper;

/*
 * Copyright (c) 1999, 2010 Tanuki Software, Ltd.
 * http://www.tanukisoftware.com
 * All rights reserved.
 *
 * This software is the proprietary information of Tanuki Software.
 * You shall use it only in accordance with the terms of the
 * license agreement you entered into with Tanuki Software.
 * http://wrapper.tanukisoftware.org/doc/english/licenseOverview.html
 */

import java.io.IOException;
import java.io.OutputStream;

/**
 * The OutputStream Class of a WrapperProcess, representing all the data the 
 * ChildProcess read from the Wrapper.
 *
 * @author Christian Mueller <christian.mueller@tanukisoftware.co.jp>
 * @since Wrapper 3.4.0
 */
public class WrapperProcessOutputStream
    extends OutputStream
{
    private long m_ptr;
    private boolean m_closed;

    /*---------------------------------------------------------------
     * Constructors
     *-------------------------------------------------------------*/
    /**
     * This class can only be instantiated by native code.
     */
    private WrapperProcessOutputStream()
    {
    }

    /*---------------------------------------------------------------
     * Native Methods
     *-------------------------------------------------------------*/
    private native void nativeWrite( int b );
    private native void nativeClose();

    /*---------------------------------------------------------------
     * Methods
     *-------------------------------------------------------------*/
    /**
     * Writes a byte to the Stream.
     *
     * @param b byte to write.
     *
     * @throws IOException in case the stream has been already closed or any
     *                     other IO error.
     */
    public void write( int b )
        throws IOException
    {
        synchronized( this )
        {
            if ( !m_closed )
            {
                nativeWrite( b );
            }
            else
            {
                throw new IOException( "Stream is closed." );
            }
        }
    }

    /**
     * Closes the OutputStream.
     *
     * @throws IOException If there were any problems closing the stream.
     */
     public void close()
        throws IOException
     {
        if ( !m_closed )
        {
            nativeClose();
            m_closed = true;
        }
    }
}
