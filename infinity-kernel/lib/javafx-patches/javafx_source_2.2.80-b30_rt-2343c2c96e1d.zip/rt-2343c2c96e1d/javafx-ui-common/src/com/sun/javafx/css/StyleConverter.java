/*
 * Copyright (c) 2010, 2012, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

package com.sun.javafx.css;

import com.sun.javafx.Logging;
import com.sun.javafx.logging.PlatformLogger;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javafx.scene.text.Font;


/**
 * Converter converts ParsedValue&lt;F,T&gt; from type F to type T.
 * F is the type of the parsed value, T is the converted type of
 * the ParsedValue. For example, a converter from String to Color would
 * be declared
 * <p>&nbsp;&nbsp;&nbsp;&nbsp;
 * <code>public Color convert(ParsedValue&lt;String,Color&gt; value, Font font)</code>
 * </p>
 */
public class StyleConverter<F, T> {

    /**
     * Convert from the parsed css value to the target property type.
     *
     * The default returns the value contained in ParsedValue.
     *
     * @param value        The value to convert
     * @param font         The font parameter is used to convert those types that are relative
     * to or inherited from a parent font.
     */
    public T convert(ParsedValue<F,T> value, Font font) {
        return (T) value.getValue();
    }

    /**
     * Convert from the constituent values to the target property type.
     * Implemented by Types that have Keys with subKeys.
     */
    public T convert(Map<StyleableProperty,Object> convertedValues) {
        return null;
    }

    private static class Holder {
        private static StyleConverter CONVERTER = new StyleConverter();
    }

    /** This converter simply returns value.getValue() */
    public static StyleConverter getInstance() {
        return Holder.CONVERTER;
    }

    protected StyleConverter() {
    }


    public void writeBinary(DataOutputStream os, StringStore sstore)
            throws IOException {

        String cname = getClass().getName();
        int index = sstore.addString(cname);
        os.writeShort(index);
    }

    // map of StyleConverter class name to StyleConverter
    private static Map<String,StyleConverter> tmap;

    public static StyleConverter readBinary(int version, DataInputStream is, String[] strings)
            throws IOException {

        int index = is.readShort();
        String cname = strings[index];

        if (cname == null || cname.isEmpty()) return null;
        
        if (cname.startsWith("com.sun.javafx.css.converters.EnumConverter")) {
            return com.sun.javafx.css.converters.EnumConverter.readBinary(version, is, strings);
        } 

        // Make a new entry in tmap, if necessary
        if (tmap == null || !tmap.containsKey(cname)) {

            StyleConverter converter = getInstance(cname);
            if (converter == null) {
                final PlatformLogger logger = Logging.getCSSLogger();
                if (logger.isLoggable(PlatformLogger.SEVERE)) {
                    logger.severe("could not deserialize " + cname);
                }
            }            
            if (tmap == null) tmap = new HashMap<String,StyleConverter>();
            tmap.put(cname, converter);
            return converter;
        }
        return tmap.get(cname);
    }


    // package for unit test purposes
    static StyleConverter getInstance(final String converterClass) {

        StyleConverter styleConverter = null;
        // TODO: giant if-then-else block
        if ("com.sun.javafx.css.StyleConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.StyleConverter.getInstance();

        } else if ("com.sun.javafx.css.converters.BooleanConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.BooleanConverter.getInstance();

        } else if ("com.sun.javafx.css.converters.ColorConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.ColorConverter.getInstance();

        } else if ("com.sun.javafx.css.converters.CursorConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.CursorConverter.getInstance();

        } else if ("com.sun.javafx.css.converters.EffectConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.EffectConverter.getInstance();
        } else if ("com.sun.javafx.css.converters.EffectConverter$DropShadowConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.EffectConverter.DropShadowConverter.getInstance();
        } else if ("com.sun.javafx.css.converters.EffectConverter$InnerShadowConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.EffectConverter.InnerShadowConverter.getInstance();
                
        } else if ("com.sun.javafx.css.converters.FontConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.FontConverter.getInstance();
        } else if ("com.sun.javafx.css.converters.FontConverter$StyleConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.FontConverter.StyleConverter.getInstance();
        } else if ("com.sun.javafx.css.converters.FontConverter$WeightConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.FontConverter.WeightConverter.getInstance();
        } else if ("com.sun.javafx.css.converters.FontConverter$SizeConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.FontConverter.SizeConverter.getInstance();

        }  else if ("com.sun.javafx.css.converters.InsetsConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.InsetsConverter.getInstance();
        }  else if ("com.sun.javafx.css.converters.InsetsConverter$SequenceConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.InsetsConverter.SequenceConverter.getInstance();

        }  else if ("com.sun.javafx.css.converters.PaintConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.PaintConverter.getInstance();
        }  else if ("com.sun.javafx.css.converters.PaintConverter$SequenceConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.PaintConverter.SequenceConverter.getInstance();
        }  else if ("com.sun.javafx.css.converters.PaintConverter$LinearGradientConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.PaintConverter.LinearGradientConverter.getInstance();
        }  else if ("com.sun.javafx.css.converters.PaintConverter$RadialGradientConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.PaintConverter.RadialGradientConverter.getInstance();

        }  else if ("com.sun.javafx.css.converters.SizeConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.SizeConverter.getInstance();
        }  else if ("com.sun.javafx.css.converters.SizeConverter$SequenceConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.SizeConverter.SequenceConverter.getInstance();

        }  else if ("com.sun.javafx.css.converters.StringConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.StringConverter.getInstance();
        }  else if ("com.sun.javafx.css.converters.StringConverter$SequenceConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.StringConverter.SequenceConverter.getInstance();

        }  else if ("com.sun.javafx.css.converters.URLConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.URLConverter.getInstance();
        }  else if ("com.sun.javafx.css.converters.URLConverter$SequenceConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.converters.URLConverter.SequenceConverter.getInstance();

        // Region stuff
        }  else if ("com.sun.javafx.scene.layout.region.BackgroundFillConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.BackgroundFillConverter.getInstance();

        }  else if ("com.sun.javafx.scene.layout.region.BackgroundImageConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.BackgroundImageConverter.getInstance();
        }  else if ("com.sun.javafx.scene.layout.region.BackgroundImage$BackgroundPositionConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.BackgroundImage.BackgroundPositionConverter.getInstance();
        }  else if ("com.sun.javafx.scene.layout.region.BackgroundImage$BackgroundRepeatConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.BackgroundImage.BackgroundRepeatConverter.getInstance();
        }  else if ("com.sun.javafx.scene.layout.region.BackgroundImage$BackgroundSizeConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.BackgroundImage.BackgroundSizeConverter.getInstance();
        }  else if ("com.sun.javafx.scene.layout.region.BackgroundImage$LayeredBackgroundPositionConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.BackgroundImage.LayeredBackgroundPositionConverter.getInstance();
        }  else if ("com.sun.javafx.scene.layout.region.BackgroundImage$LayeredBackgroundSizeConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.BackgroundImage.LayeredBackgroundSizeConverter.getInstance();

        }  else if ("com.sun.javafx.scene.layout.region.BorderImageConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.BorderImageConverter.getInstance();
        }  else if ("com.sun.javafx.scene.layout.region.BorderImage$RepeatConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.BorderImage.RepeatConverter.getInstance();
        }  else if ("com.sun.javafx.scene.layout.region.BorderImage$SliceConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.BorderImage.SliceConverter.getInstance();
        }  else if ("com.sun.javafx.scene.layout.region.BorderImage$SliceSequenceConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.BorderImage.SliceSequenceConverter.getInstance();

        }  else if ("com.sun.javafx.scene.layout.region.StrokeBorderConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.StrokeBorderConverter.getInstance();
        }  else if ("com.sun.javafx.scene.layout.region.StrokeBorder$BorderPaintConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.StrokeBorder.BorderPaintConverter.getInstance();
        }  else if ("com.sun.javafx.scene.layout.region.StrokeBorder$BorderStyleConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.StrokeBorder.BorderStyleConverter.getInstance();
        }  else if ("com.sun.javafx.scene.layout.region.StrokeBorder$BorderStyleSequenceConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.StrokeBorder.BorderStyleSequenceConverter.getInstance();
        }  else if ("com.sun.javafx.scene.layout.region.StrokeBorder$LayeredBorderPaintConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.StrokeBorder.LayeredBorderPaintConverter.getInstance();
        }  else if ("com.sun.javafx.scene.layout.region.StrokeBorder$LayeredBorderStyleConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.StrokeBorder.LayeredBorderStyleConverter.getInstance();

        }  else if ("com.sun.javafx.scene.layout.region.Margins$Converter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.Margins.Converter.getInstance();
        }  else if ("com.sun.javafx.scene.layout.region.Margins$SequenceConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.scene.layout.region.Margins.SequenceConverter.getInstance();

        // parser stuff
        }  else if ("com.sun.javafx.css.parser.DeriveColorConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.parser.DeriveColorConverter.getInstance();
        }  else if ("com.sun.javafx.css.parser.DeriveSizeConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.parser.DeriveSizeConverter.getInstance();
        }  else if ("com.sun.javafx.css.parser.LadderConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.parser.LadderConverter.getInstance();
        }  else if ("com.sun.javafx.css.parser.StopConverter".equals(converterClass)) {
            styleConverter = com.sun.javafx.css.parser.StopConverter.getInstance();
        }

        return styleConverter;
    }

}
